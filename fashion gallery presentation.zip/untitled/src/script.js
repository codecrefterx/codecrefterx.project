

let slides = document.querySelectorAll('.slide');

let currentSlide = 0;

// Function to show a specific slide

function showSlide(index) {

    slides[currentSlide].classList.remove('active'); // Hide the current slide

    currentSlide = (index + slides.length) % slides.length; // Loop back if at the end

    slides[currentSlide].classList.add('active');

}



function nextSlide() {

    showSlide(currentSlide + 1);

}



function prevSlide() {

    showSlide(currentSlide - 1);

}

document.getElementById('next').addEventListener('click', nextSlide);

document.getElementById('prev').addEventListener('click', prevSlide);